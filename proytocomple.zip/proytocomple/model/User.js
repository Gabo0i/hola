import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
  name: String,
  age: String,
  role: String
});

const User = mongoose.model('User', UserSchema);

export { User }; // Exporta el modelo utilizando un nombre específico
