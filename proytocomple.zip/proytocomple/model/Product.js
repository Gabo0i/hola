import mongoose from "mongoose";

const Product = mongoose.Schema(
  {
    nombre: String,
    precio: Number,
    descripcion: String,
    imagen: String, 
    cantidad: Number,
    id: Number, 
    categoria: String
  },
  {
    timestamps: true,
  }
);

export default mongoose.models.Product || mongoose.model("Product", Product);  