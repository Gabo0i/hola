"use client";

import { useSession, signOut } from "next-auth/react";
import Link from "next/link";

const Header = () => {
    const { data: session } = useSession();

    return (
        <header className="flex items-center justify-between p-4 bg-gray-800 text-white">
            <nav className="flex gap-8 items-center">
                <Link href="/" className="text-2xl font-semibold text-red-600">
                    &#127789; Mr. Tocomple
                </Link>
                <Link href="/" className="hover:text-red-400">Home</Link>
                <Link href="/productos" className="hover:text-red-400">Productos</Link>
                <Link href="/servicios" className="hover:text-red-400">Servicios</Link>
                <Link href="/contacto" className="hover:text-red-400">Contacto</Link>
            </nav>
            <div>
                {session ? (
                    <div className="flex items-center">
                        <span className="mr-4">Bienvenido, {session.user.email}</span>
                        <button onClick={() => signOut()} className="bg-red-600 px-4 py-2 rounded-full hover:bg-red-700">
                            Cerrar sesión
                        </button>
                    </div>
                ) : (
                    <div className="flex items-center">
                        <Link href="/login" className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 mr-2">
                            Login
                        </Link>
                        <Link href="/registro" className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700">
                            Registro
                        </Link>
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;