const index = ({texto='Mockup'}) => {
  return (
    <button className="bg-red-600 text-white rounded-full px-6 py-2 hover:scale-105">{texto}</button>
  )
}

export default index