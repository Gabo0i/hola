import { model, models, Schema } from "mongoose";

const UserSchema = new Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, validate: passwd => {
        if (!passwd?.length || passwd.length < 8) {
            throw new Error('Password must be at least 8 characters');
        }
    } }
}, { timestamps: true });

export const User = models?.User || model('User', UserSchema);