import React from 'react';

const ServiciosPage = () => {
  return (
    <div className="p-8 max-w-6xl mx-auto bg-gray-100 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold text-center mb-6 text-gray-800">Nuestros Servicios</h1>
      <p className="text-lg text-gray-700 mb-8 text-center">
        En nuestra tienda de completos, nos enorgullece ofrecer una variedad de servicios diseñados para satisfacer todas tus necesidades. Aquí están algunos de los servicios que ofrecemos:
      </p>
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-2 text-gray-800">Completos Personalizados</h2>
          <p className="text-gray-700">
            Ofrecemos la opción de personalizar tus completos con una variedad de ingredientes frescos. Elige entre nuestras opciones o crea tu propio completo a medida.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-2 text-gray-800">Servicio de Catering</h2>
          <p className="text-gray-700">
            ¿Tienes un evento o una reunión? Nuestro servicio de catering te proporciona completos deliciosos y bien preparados para tus ocasiones especiales.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-2 text-gray-800">Pedidos a Domicilio</h2>
          <p className="text-gray-700">
            Disfruta de nuestros completos en la comodidad de tu hogar con nuestro servicio de entrega a domicilio. Realiza tu pedido en línea y te lo llevamos a tu puerta.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-2 text-gray-800">Eventos Especiales</h2>
          <p className="text-gray-700">
            Organiza tu evento con nosotros y ofrecemos un menú exclusivo de completos para hacer de tu celebración un éxito.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ServiciosPage;