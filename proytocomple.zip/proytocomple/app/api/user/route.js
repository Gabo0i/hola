import { User } from "@/app/models/user";
import connectDB from "@/lib/connectionDB";
import { NextResponse } from "next/server";

export async function GET() {
    await connectDB();
    try {
        const users = await User.find();
        return NextResponse.json(users);
    } catch (error) {
        return NextResponse.json({ error: 'Error fetching users' }, { status: 500 });
    }
}

export async function POST(req) {
    await connectDB();
    
    const { nombre, edad } = await req.json();

    const person = new User({
        name: nombre,
        age: edad
    });
    await person.save();
    console.log("DATOS RECIBIDOS EN API", nombre, edad);
    return NextResponse.json({ message: 'saved' });
}

export async function UPDATE(req) {
    return NextResponse.json({ message: 'Not Implemented yet' });
}

export async function DELETE(req) {
    return NextResponse.json({ message: 'Not Implemented yet' });
}