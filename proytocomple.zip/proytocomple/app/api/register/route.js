import connectDB from "../../../lib/connectionDB";
import { User } from "../../models/user"; // Importa User utilizando destructuración

export default async function handler(req, res) {
  const { method, body } = req;

  try {
    await connectDB(); // Conecta con la base de datos

    switch (method) {
      case 'POST':
        const { name, age, role } = body;

        // Crea un nuevo usuario utilizando el modelo User
        const newUser = new User({
          name,
          age,
          role
        });

        // Guarda el nuevo usuario en la base de datos
        const savedUser = await newUser.save();

        res.status(201).json({ success: true, data: savedUser });
        break;

      default:
        res.setHeader('Allow', ['POST']);
        res.status(405).end(`Method ${method} Not Allowed`);
    }
  } catch (error) {
    console.error('Error connecting to database or saving user:', error.message);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
}