import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import connectDB from "@/lib/connectionDB";
import { User } from "@/app/models/user";
import crypto from 'crypto'; // Importa el módulo crypto para usar MD5

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: "Email", type: "email", placeholder: "jsmith@build.com" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        await connectDB();
        const user = await User.findOne({ email: credentials.email });

        // Crea un hash MD5 de la contraseña ingresada para compararla
        const hashedPassword = crypto.createHash('md5').update(credentials.password).digest('hex');

        if (user && hashedPassword === user.password) {
          return {
            id: user._id.toString(), // Asegúrate de convertir el ID a una cadena
            email: user.email,
            name: user.name
          };
        } else {
          return null;
        }
      },
    }),
  ],
  pages: {
    signIn: '/login', // Ruta personalizada para la página de inicio de sesión
  },
  session: {
    strategy: 'jwt', // Utiliza JWT para manejar la sesión
  },
  callbacks: {
    async session({ session, token }) {
      // Agrega los datos del usuario al objeto de sesión
      session.user = token.user;
      return session;
    },
    async jwt({ token, user }) {
      // Si hay un usuario, agrega los datos del usuario al token JWT
      if (user) {
        token.user = user;
      }
      return token;
    },
    async redirect({ url, baseUrl }) {
      // Redirige a la página de inicio después de iniciar sesión
      return baseUrl;
    }
  },
});

export { handler as GET, handler as POST };