import { NextResponse } from "next/server";
import products from "@/mockup/products.json";

export async function GET() {
  try {
    return NextResponse.json(products.data);
  } catch (error) {
    console.error("Error fetching products:", error);
    return NextResponse.json({ error: 'Error fetching products' }, { status: 500 });
  }
}