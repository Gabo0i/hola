"use client";
import { useState } from "react";

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user'); // Por defecto, el rol es usuario común

  function handleFormSubmit(e) {
    e.preventDefault();

    // Si el rol seleccionado es 'admin', podrías agregar lógica para solicitar un código especial aquí

    const userData = {
      email,
      password,
      role, // Incluir el rol en los datos enviados al backend
    };

    fetch('/api/register', {
      method: 'POST',
      body: JSON.stringify(userData),
      headers: {'Content-Type': 'application/json'}
    }).then(response => {
      if (response.ok) {
        // Registro exitoso, puedes manejar la redirección o mostrar un mensaje de éxito
        console.log('Usuario registrado correctamente');
      } else {
        // Manejar errores de registro
        console.error('Error al registrar usuario:', response.statusText);
      }
    }).catch(error => {
      console.error('Error en la solicitud:', error);
    });
  }

  return (
    <section className="mt-8">
      <h1 className="text-center text-2xl">Registro</h1>
      <form className="block mx-auto max-w-xs" onSubmit={handleFormSubmit}>
        <input
          type="email"
          placeholder="Escribe tu Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Escribe tu Clave"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
        <label>
          Selecciona tu rol:
          <select value={role} onChange={e => setRole(e.target.value)}>
            <option value="user">Usuario</option>
            <option value="admin">Administrador</option>
          </select>
        </label>
        {role === 'admin' && (
          <div>
            <input
              type="text"
              placeholder="Ingresa código especial"
              // Aquí podrías manejar el código especial para administradores
            />
          </div>
        )}
        <button type="submit">Registrar</button>
      </form>
    </section>
  );
};

export default RegisterPage;
