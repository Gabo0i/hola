"use client"; // Marca este archivo como un Client Component

import { useState, useEffect } from "react";
import { signIn } from "next-auth/react";

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Aquí puedes colocar cualquier lógica que necesites para efectos secundarios
    console.log('Componente montado');
  }, []); // El array vacío [] asegura que el efecto solo se ejecute una vez al montar el componente

  async function handleFormSubmit(e) {
    e.preventDefault();
    setLoading(true);

    const result = await signIn('credentials', {
      redirect: false,
      email,
      password,
    });

    if (result?.ok) {
      console.log('Inicio de sesión exitoso:', result);
      // Aquí puedes manejar la redirección o cualquier otra lógica de éxito de inicio de sesión
    } else {
      console.error('Error al iniciar sesión:', result?.error);
      // Aquí puedes manejar los errores de inicio de sesión
    }

    setLoading(false);
  }

  return (
    <section className="mt-8">
      <h1 className="text-center text-2xl">Login</h1>
      <form className="block mx-auto max-w-xs" onSubmit={handleFormSubmit}>
        <input
          type="email"
          className="my-2 p-2 w-full"
          placeholder="Escribe tu Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
        />
        <input
          type="password"
          className="my-2 p-2 w-full"
          placeholder="Escribe tu Clave"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
        <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          {loading ? 'Cargando...' : 'Iniciar Sesión'}
        </button>
      </form>
    </section>
  );
};

export default LoginPage;
