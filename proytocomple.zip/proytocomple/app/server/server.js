const express = require('express');
const registerRouter = require('./api/register'); // Asegúrate de que la ruta sea correcta

const app = express();

app.use(express.json());
app.use('/api', registerRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));