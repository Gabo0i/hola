import React from 'react';

const ContactoPage = () => {
  return (
    <div className="p-8 max-w-6xl mx-auto bg-gray-100 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold text-center mb-6 text-gray-800">Contáctanos</h1>
      <p className="text-lg text-gray-700 mb-4 text-center">
        Si tienes alguna pregunta o inquietud, no dudes en ponerte en contacto con nosotros.
      </p>
      <div className="flex flex-col items-center">
        <p className="text-lg text-gray-700 mb-4">
          <strong>Teléfono:</strong> <a href="tel:+1234567890" className="text-blue-600 hover:underline">+56923819059</a>
        </p>
        <p className="text-lg text-gray-700 mb-4">
          <strong>Correo electrónico:</strong> <a href="mailto:info@example.com" className="text-blue-600 hover:underline">completossantiago@gmail.com</a>
        </p>
        {/* Puedes agregar más información de contacto aquí */}
      </div>
    </div>
  );
};

export default ContactoPage;