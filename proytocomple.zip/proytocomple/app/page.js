"use client";

import { useState, useEffect } from 'react';
import Hero from '@/components/Hero';
import Card from '@/components/Card';

export default function Home() {
  const [productos, setProductos] = useState([]);
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProducts() {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log("Products fetched in Home:", data); 
        setProductos(data);
      } catch (error) {
        console.error('Error fetching products:', error); 
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, []);

  if (isLoading) return <p>Cargando productos...</p>;

  return (
    <main className="mx-auto max-w-6xl p-4">
      <Hero />
      <div>
        <h2 className='font-bold text-2xl text-center m-4'>Productos</h2>
        <div className='grid grid-cols-4 gap-4'>
          {productos.length > 0 ? (
            productos.map((product) => (
              <Card key={product.id} dato={product} />
            ))
          ) : (
            <p>No hay productos disponibles.</p>
          )}
        </div>
      </div>
    </main>
  );
}