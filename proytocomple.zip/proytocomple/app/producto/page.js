'use client'
import React, { useEffect, useState } from 'react';

const ProductosPage = () => {
  const [productos, setProductos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          throw new Error('Error fetching products');
        }
        const data = await response.json();
        setProductos(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (isLoading) return <p>Cargando productos...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-4">Productos</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {productos.map((producto) => (
          <div key={producto._id} className="border rounded-lg overflow-hidden shadow-lg">
            <img src={`/assets/img/mockups/${producto.imagen}`} className="object-cover w-full h-48" />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{producto.nombre}</h2>
              <p className="text-gray-600 mb-2">{producto.descripcion}</p>
              <p className="text-red-600 font-bold">${producto.precio}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductosPage;